/* The slideshow effect for Web Developement*/
$('#carouselFade').carousel();

setInterval(function() { 
  $('#slideshow > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slideshow');
},  3000);


AOS.init();